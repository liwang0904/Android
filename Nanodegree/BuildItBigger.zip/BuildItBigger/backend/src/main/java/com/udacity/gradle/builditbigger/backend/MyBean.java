package com.udacity.gradle.builditbigger.backend;

public class MyBean {
    public void setData(String data) {
    }
}